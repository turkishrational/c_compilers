.global main
.text

/* _start etiketini sildik, TCC doğrudan bu ilk talimattan baslayacak */
_start_entry:
    jmp .L_START

    .ascii "CRT0"

.L_START:
    /* ========================================================================= */
    /* [TRDOS PARAMS & MAIN RUN]: Saf Stack Duzeni (AT&T Style)                  */
    /* ========================================================================= */
    popl %eax                       /* argc degerini %eax'e cek */
    movl %esp, %ebx                 /* %esp (argv pointer) -> %ebx */
    pushl %ebx                      /* Ikinci parametre: argv */
    pushl %eax                      /* Birinci parametre: argc */
    
    call main                       /* Alt cizgiyi kaldirdik! TCC 'main' sembolunu baglayacak */
    
    addl $8, %esp                   /* Stack temizligi (2 adet dword) */
    
    /* ========================================================================= */
    /* [TERMINATION]: main()'den donen exit code ile guvenli cikis               */
    /* ========================================================================= */
    movl %eax, %ebx                 /* main()'in donus degeri (%eax) -> %ebx (exit code) */
    movl $1, %eax                   /* %eax = 1 (sys_exit) */
    int $0x40                       /* TRDOS Kernel Resmi Kesmesi */

    .byte 0
    .ascii "TCC Native CRT0 for TRDOS 386"
    .byte 0
    .ascii "Erdogan Tan & Google AI - 2026"
    .byte 0
