/* ===========================================================================
   TRDOS 386 - TEK�L VE G�VENL� SBRK MOTORU (sbrk.s)
   =========================================================================== */
.intel_syntax noprefix
.global _sbrk
.extern _end       /* Linker'dan gelen BSS biti� koordinat� */

.text
_sbrk:
    push ebp
    mov ebp, esp
    push ebx
    push ecx

    mov ecx, [ebp + 8]    /* �stenen byte boyutu (size) */
    
    /* DWORD Hizalamas� (Her ihtimale kar�� sbrk seviyesinde z�rh) */
    add ecx, 3
    and ecx, 0xFFFFFFFC

    /* �lk �a�r� kontrol� */
    mov eax, [current_break]
    test eax, eax
    jnz .L_calc_new
    
    /* �lk �a�r�da taban adresi _end olarak m�h�rleniyor */
    mov eax, offset _end
    add eax, 3
    and eax, 0xFFFFFFFC
    mov [current_break], eax

.L_calc_new:
    mov ebx, [current_break] /* EBX = Eski u.break (Geri d�necek olan ge�erli adres) */
    mov edx, ebx
    add edx, ecx           /* EDX = Yeni u.break s�n�r� */

    /* TRDOS Kernel sys_break (17) �a�r�s� */
    push ebx
    mov ebx, edx
    mov eax, 17
    int 0x40
    pop ebx
    
    /* Hata Kontrol� (Carry Flag veya EAX < 0 kontrol� yap�labilir) */
    cmp eax, 0
    jl .L_err

    /* Ba�ar�l� ise global g�stergeyi g�ncelle */
    mov [current_break], edx

    /* Demand Paging & Zero-Fill Z�rh�: Yeni alan� el ile tetikle ve temizle */
    push edi
    mov edi, ebx           /* Ba�lang�� adresi */
    shr ecx, 2             /* DWORD say�s�na b�l (ecx / 4) */
    xor eax, eax           /* Yaz�lacak de�er: 0 */
    rep stosd              /* T�m yeni alan� s�f�rla ve sayfalar� Ring 3'e ba�la */
    pop edi

    mov eax, ebx           /* Eski break adresini (tahsis edilen yerin ba��) d�nd�r */
    jmp .L_done

.L_err:
    xor eax, eax           /* Bellek bittiyse NULL (0) d�n */

.L_done:
    pop ecx
    pop ebx
    pop ebp
    ret

current_break: .long 0  /* T�m sistemin tekil u.break izleyicisi */
