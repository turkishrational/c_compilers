.intel_syntax noprefix
.global _ldexp
.global ldexp
.text

_ldexp:
ldexp:
    push ebp
    mov ebp, esp
    
    fild dword ptr [ebp + 16]    /* �ss� (exp) integer olarak FPU y���n�na y�kle */
    fld qword ptr [ebp + 8]      /* Mantis'i (x) double olarak FPU y���n�na y�kle */
    fscale                       /* ST(0) = ST(0) * 2^ST(1) i�lemini �ak */
    fstp st(1)                   /* �s de�erini FPU'dan temizle, sonu� st(0)'da kal�r */
    
    pop ebp
    ret
