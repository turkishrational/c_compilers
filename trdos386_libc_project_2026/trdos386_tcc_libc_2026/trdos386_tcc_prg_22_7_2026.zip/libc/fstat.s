.intel_syntax noprefix
.global _fstat
.global fstat
.text

_fstat:
fstat:
    push ebp
    mov ebp, esp
    push ebx              /* cdecl korumas� */

    mov ebx, [ebp + 8]    /* Argument 1: LIBC FD (3-12 aras�) */

    mov ecx, [ebp + 12]   /* Argument 2: struct stat *buf bellek adresi */

    /* �NEML�: Standart ak��lar (0,1,2) i�in fstat istenirse disk sorgusu yapma, n�tr d�n */
    cmp ebx, 3
    jl .L_fstat_stub

    sub ebx, 3            /* LIBC FD -> TRDOS FD (0-9) d�n���m� */

    mov eax, 47           /* _fstat equ 47 (TRDOS 386 v2.0.11 Kernel API) */
    int 0x40              /* �ekirdek Kesmesi */

.L_fstat_done:
    pop ebx
    pop ebp
    ret

.L_fstat_stub:
    /* stdin/out/err i�in sahte tampon doldurma (��kmeyi �nleme z�rh�) */
    xor eax, eax
    mov [ecx], eax        /* st_dev = 0 */
    mov [ecx + 20], eax   /* st_size = 0 */
    jmp .L_fstat_done


