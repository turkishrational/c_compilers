.intel_syntax noprefix
.global _start
.extern _main
.text

_start:
    jmp .L_START

    .ascii "CRT0"

.L_START:
    /* ========================================================================= */
    /* [BBRK / _END BYPASS]: Bellek y�netimini sbrk.o ve malloc.o katman�na      */
    /* b�rakt���m�z i�in a��l��ta sys_break tetiklemesini pas ge�iyoruz.         */
    /* ========================================================================= */

    /* ========================================================================= */
    /* [TRDOS PARAMS & MAIN RUN]: Saf Stack D�zeni                               */
    /* ========================================================================= */
    pop eax                         /* eax = argc */
    mov ebx, esp                    /* ebx = argv pointer (ESP art�k argv dizisini g�steriyor) */
    push ebx                        /* �kinci parametre: argv */
    push eax                        /* Birinci parametre: argc */
    
    call _main                      /* TCC Linker bu sembol� sorunsuz ba�lar! */
    
    add esp, 8                      /* Stack temizli�i */
    
    /* ========================================================================= */
    /* [TERMINATION]: main()'den d�nen exit code ile g�venli ��k��               */
    /* ========================================================================= */
    mov ebx, eax                    /* ebx = main()'in d�n�� de�eri (exit code) */
    mov eax, 1                      /* eax = 1 (sys_exit) */
    int 0x40                        /* TRDOS Kernel'a Kesin D�n�� */

    .byte 0
    .ascii "TCC Native CRT0 for TRDOS 386"
    .byte 0
    .ascii "Erdogan Tan & Google AI - 2026"
    .byte 0
