/* 09/08/2026 - Google AI - TCC.PRG  0.9.24 self-compiling */  
/* tcc_trdos.h - TRDOS 386 için TCC Yamama Başlığı */

#ifndef TCC_TRDOS_H
#define TCC_TRDOS_H

/* 1. Temel Makrolar */
#ifndef NULL
#define NULL ((void *)0)
#endif

/* 2. Dosya Açma Modları (POSIX/Standart Değerler) */
#define O_RDONLY    0x0000
#define O_WRONLY    0x0001
#define O_RDWR      0x0002
#define O_CREAT     0x0100
#define O_TRUNC     0x0200

/* 3. Errno Değişkenini Tamamen İptal Etme Makrosu */
/* tcc.c içindeki "errno" yazan her yer doğrudan 0 sabitiyle değiştirilir, hafızada değişken aranmaz */
extern int _errno;
#define errno _errno

/* size_t Veri Tipi Tanımı (offsetof makrosunun hata vermesini engeller) */
typedef unsigned int size_t;

/* time_t Veri Tipi Tanımı */
typedef long time_t;

/* Standart Zaman Yapısı (3912. satırdaki tm_mon hatasını çözer) */
struct tm {
    int tm_sec;   /* saniye (0-60) */
    int tm_min;   /* dakika (0-59) */
    int tm_hour;  /* saat (0-23) */
    int tm_mday;  /* ayın günü (1-31) */
    int tm_mon;   /* ay (0-11) -> TCC'nin aradığı alan */
    int tm_year;  /* yıl - 1900 */
    int tm_wday;  /* haftanın günü (0-6, Pazar=0) */
    int tm_yday;  /* yılın günü (0-365) */
    int tm_isdst; /* yaz saati uygulaması flag'i */
};

/* Zaman Fonksiyon Prototipleri (Implicit uyarılarını ve pointer bozulmalarını önler) */
time_t time(time_t *tloc);
struct tm *localtime(const time_t *tloc);

/* 4. lseek Fonksiyonu İçin Standart Konum Makroları (SEEK_SET hatasını çözer) */
#define SEEK_SET    0
#define SEEK_CUR    1
#define SEEK_END    2

/* 5. Eksik Prototiplerin Tam Tanımlanması (Implicit Hatalarını ve GPF'yi Önler) */
void *memset(void *s, int c, unsigned int n);
int memcmp(const void *s1, const void *s2, unsigned int n);
void *memmove(void *dest, const void *src, unsigned int n);
void *memcpy(void *dest, const void *src, unsigned int n);
int sprintf(char *str, const char *format, ...);
double ldexp(double x, int exp);

// #define _memcpy memcpy

/* 6. String Fonksiyon Prototipleri (Uyarıları Engellemek İçin) */
unsigned int strlen(const char *s);
char *strcpy(char *dest, const char *src);
char *strcat(char *dest, const char *src);
int strcmp(const char *s1, const char *s2);
char *strchr(const char *s, int c);
char *strrchr(const char *s, int c);

/* 7. Temel Giriş/Çıkış ve Bellek Fonksiyon Prototipleri */
int open(const char *pathname, int flags, ...);
int close(int fd);
int read(int fd, void *buf, unsigned int count);
void *malloc(unsigned int size);
void free(void *ptr);
void *realloc(void *ptr, unsigned int size);

/* 8. Eksik Sayısal Dönüşüm Prototipleri
/* strtod Fonksiyon Prototipi (implicit uyarısını ve stack kaymasını önler) */
double strtod(const char *nptr, char **endptr);
/* (tccasm.c uyarılarını ve taşmaları önler) */
unsigned long strtoul(const char *nptr, char **endptr, int base);
long long strtoll(const char *nptr, char **endptr, int base);
unsigned long long strtoull(const char *nptr, char **endptr, int base);

/* 9. Düşük Seviyeli lseek Prototipi */
long lseek(int fd, long offset, int whence);

/* 10. mingw_hack.s içindeki assembly motoruna doğrudan makro köprüsü */
extern void *___mingw_realloc(void *ptr, unsigned int size);
/* Kod içindeki tcc_realloc ve düz realloc çağrılarının tamamını assembly motoruna bağlar */
#define realloc __mingw_realloc
#define tcc_realloc __mingw_realloc

/* 11. tcc x86 fpu dahili, kontrol sembolleri (trdos 386 mührü) */
/* GCC'nin otomatik alt çizgi ekleme huyuna karşı düz adlarıyla tanımlıyoruz */
unsigned short __tcc_fpu_control = 0x137f;
unsigned short __tcc_int_fpu_control = 0x137f | 0x0c00;

#endif /* TCC_TRDOS_H */
