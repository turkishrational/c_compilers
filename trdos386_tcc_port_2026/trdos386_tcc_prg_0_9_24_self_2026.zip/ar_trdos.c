/* =======================================================================
   TRDOS 386 - Native Static Library Archiver Windows Emulator (AR.EXE)
   Date: 10/08/2026 - Developer: Erdogan Tan & Google AI
   Format: Pure Standard C (Compatible with GCC and TCC)
   Standard: UNIX/ELF Static Archive (.a) Generator Matching ar.s
   ======================================================================= */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define IO_BUFFER_SIZE 4096

/* Sabit Tanımlamalar (ar.s SECTION .data ile birebir eşleşme) */
const char msg_magic[]  = "!<arch>\n";
const char static_date[] = "1784157100";
const char static_mode[] = "100644";
const char msg_pad      = 0x0A;

int main(int argc, char *argv[]) {
    FILE *out_fd = NULL;
    FILE *in_fd = NULL;
    unsigned char io_buffer[IO_BUFFER_SIZE];
    char ar_header[60];
    char obj_name[16];
    long obj_size;
    int i, name_len;
    size_t bytes_read;

    /* 1. ADIM: Komut Satırı Argümanlarını Tarama */
    if (argc < 3) {
        printf("TRDOS 386 Archiver Windows Emulator v1.0\n");
        printf("Usage: AR <archive.a> <file1.o> [file2.o] ...\n");
        return 1;
    }

    /* 2. ADIM: Hedef Kütüphane Dosyasını Oluştur (SYS_CREAT muadili) */
    out_fd = fopen(argv[1], "wb");
    if (!out_fd) {
        printf("[ERROR] Could not create destination archive file!\n");
        return 1;
    }

    /* 3. ADIM: Global Arşiv Sihirli Numarasını Yaz ("!<arch>\n") */
    if (fwrite(msg_magic, 1, 8, out_fd) != 8) {
        printf("[ERROR] Write error occurred on target device!\n");
        fclose(out_fd);
        return 1;
    }

    /* 4. ADIM: Nesne Dosyalarını Döngüsel Olarak İşleme (.loop_objects) */
    for (i = 2; i < argc; i++) {
        /* Girdi dosyasını aç (SYS_OPEN muadili) */
        in_fd = fopen(argv[i], "rb");
        if (!in_fd) {
            printf("[ERROR] Target object module file not found: %s\n", argv[i]);
            fclose(out_fd);
            return 1;
        }

        /* Girdi dosyasının boyutunu bul (SYS_SEEK sonu ve başı) */
        fseek(in_fd, 0, SEEK_END);
        obj_size = ftell(in_fd);
        fseek(in_fd, 0, SEEK_SET);

        /* 5. ADIM: 60-byte UNIX Standart Arşiv Başlığı Hazırlama (prepare_ar_header) */
        memset(ar_header, ' ', 60);

        /* Sona '/' ekleyerek dosya adını yerleştir (ar.s .name_done) */
        char *base_name = strrchr(argv[i], '\\');
        if (!base_name) base_name = strrchr(argv[i], '/');
        if (!base_name) base_name = argv[i];
        else base_name++; /* Slash karakterini atla */

        name_len = sprintf(obj_name, "%.14s/", base_name);
        memcpy(ar_header, obj_name, name_len);

        /* Zaman Damgası (12 byte - Ofset 16) */
        memcpy(ar_header + 16, static_date, 10);

        /* Owner & Group ID (6 + 6 byte - Ofset 28 ve 34) */
        ar_header[28] = '0';
        ar_header[34] = '0';

        /* Dosya İzin Maskesi (8 byte - Ofset 40) */
        memcpy(ar_header + 40, static_mode, 6);

        /* Dosya Boyutu Metin Dönüşümü (10 byte - Ofset 48, sağa dayalı) */
        char size_str[12];
        int size_len = sprintf(size_str, "%ld", obj_size);
        memcpy(ar_header + 48 + (10 - size_len), size_str, size_len);

        /* Kapanış İmzası (2 byte - Ofset 58 -> 0x60, 0x0A) */
        ar_header[58] = 0x60;
        ar_header[59] = 0x0A;

        /* Hazırlanan 60 byte başlığı arşiv dosyasına yaz */
        if (fwrite(ar_header, 1, 60, out_fd) != 60) {
            printf("[ERROR] Write error occurred on target device!\n");
            fclose(in_fd);
            fclose(out_fd);
            return 1;
        }

        /* 6. ADIM: Nesne Kodunun İçeriğini Arşive Kopyala (.read_write_loop) */
        while ((bytes_read = fread(io_buffer, 1, IO_BUFFER_SIZE, in_fd)) > 0) {
            if (fwrite(io_buffer, 1, bytes_read, out_fd) != bytes_read) {
                printf("[ERROR] Write error occurred on target device!\n");
                fclose(in_fd);
                fclose(out_fd);
                return 1;
            }
        }

        fclose(in_fd);

        /* 7. ADIM: .object_done Kuralı: Eğer nesne boyutu tek sayı ise padding (0x0A) ekle */
        if (obj_size % 2 != 0) {
            if (fwrite(&msg_pad, 1, 1, out_fd) != 1) {
                printf("[ERROR] Write error occurred on target device!\n");
                fclose(out_fd);
                return 1;
            }
        }
    }

    fclose(out_fd);
    printf("[OK] Static ELF archive library created successfully.\n");
    return 0;
}
