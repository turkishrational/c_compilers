@echo off
setlocal enabledelayedexpansion

echo ====================================================
echo   TRDOS 386 - OBJCOPY DESTEKLI ELF32 LIBC DERLEYICI
echo ====================================================

rem Klasör Yolları ve Araç Konumları
set BASE_DIR=C:\TDM-GCC-32\tinycc
set LIBC_SRC=%BASE_DIR%\libc
set OUT_DIR=%BASE_DIR%\tcclibc
set GCC_AS=C:\TDM-GCC-32\bin\as.exe
set GCC_OBJCOPY=C:\TDM-GCC-32\bin\objcopy.exe
set TCC_EXE=%BASE_DIR%\tcc.exe

rem Çıktı klasörünü sıfırla
if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"

if not exist "%GCC_OBJCOPY%" (
    echo [HATA] %GCC_OBJCOPY% bulunamadi! TDM-GCC path kontrol edin.
    pause
    exit /b 1
)

echo.
echo [1/2] Kaynak kodlar derleniyor ve SAF ELF32'ye donusturuluyor...

rem --- C DOSYALARI ---
for %%c in (libc_core libc_support) do (
    if exist "%LIBC_SRC%\%%c.c" (
        echo   [C] -^> %%c.c
        "%TCC_EXE%" -c "%LIBC_SRC%\%%c.c" -o "%OUT_DIR%\%%c_tmp.o"
        
        rem C dosyalarını da --strip-unneeded filtresinden geçirerek saf i386 ELF yapıyoruz
        "%GCC_OBJCOPY%" -I elf32-i386 -O elf32-i386 --strip-unneeded "%OUT_DIR%\%%c_tmp.o" "%OUT_DIR%\%%c.o" 2>nul
        if errorlevel 1 (
            "%GCC_OBJCOPY%" -O elf32-i386 --strip-unneeded "%OUT_DIR%\%%c_tmp.o" "%OUT_DIR%\%%c.o"
        )
        del "%OUT_DIR%\%%c_tmp.o"
    )
)

rem --- ASSEMBLY DOSYALARI (.S) ---
for %%f in (memset memcpy strlen strcmp strcpy memcmp strchr strrchr memmove strncmp chkstk gcc_stubs strcat atoi strpbrk lseek tell open close read write math64 mingw_hack libc_printf_bridge libc_itoa malloc fstat strstr freeopen ldexp win32_stubs) do (
    if exist "%LIBC_SRC%\%%f.s" (
        echo   [ASM] -^> %%f.s
        
        rem 1. Adım: Önce as.exe ile geçici nesne dosyası üret
        "%GCC_AS%" --32 "%LIBC_SRC%\%%f.s" -o "%OUT_DIR%\%%f_tmp.o"
        
        rem 2. Adım: objcopy ile geçici dosyayı SAF ELF32-i386 biçimine dönüştür ve --strip-unneeded ile arındır!
        "%GCC_OBJCOPY%" -I elf32-x86-64 -O elf32-i386 --strip-unneeded "%OUT_DIR%\%%f_tmp.o" "%OUT_DIR%\%%f.o" 2>nul
        if errorlevel 1 (
            rem Eğer girdi zaten x86-64 değilse, varsayılan formattan i386'ya zorla ve arındır
            "%GCC_OBJCOPY%" -O elf32-i386 --strip-unneeded "%OUT_DIR%\%%f_tmp.o" "%OUT_DIR%\%%f.o"
        )
        
        rem Geçici dosyayı temizle
        del "%OUT_DIR%\%%f_tmp.o"
    )
)

echo.
echo [2/2] Saf nesne dosyalari TCC ile libc.a arsivine donusturuluyor...
cd /d "%OUT_DIR%"

rem rcS parametresi (Büyük S) Big-Endian haritanın oluşmasını kesinlikle engeller!
"%TCC_EXE%" -ar rcS libc.a *.o

echo ====================================================
echo   TAMAMLANDI: Objcopy ile donusturulmus tam uyumlu
echo   Gercek ve temiz libc.a su konumda: %OUT_DIR%\libc.a
echo ====================================================
pause

