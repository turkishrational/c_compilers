.intel_syntax noprefix
.global main
.text

/* TRDOS 386 Sabitleri */
.equ _exit, 1
.equ _video, 31

main:
    /* DIRECT VGA MEMORY ACCESS */
    mov bh, 5             /* Direct access/map to VGA memory (0A0000h) */
    mov al, 0x1F          /* sys _video ; TRDOS 386 Video functions */
    int 0x40              /* TRDOS 386 system call */

    /* eax = 0A0000h */
    and eax, eax
    jz terminate          /* error (eax = 0) */
    
    /* ah = 0 */
    mov al, 0x13          /* set video mode to 13h */
    int 0x31              /* TRDOS 386 - VIDEO Interrupt */

    mov al, 0x3F
    mov cx, 0x300
    mov edi, 0xA00C0
    rep stosb
    
    mov esi, 0xA00BF
    xor ah, ah
    call sub_101A8
    
    mov ah, 1
    call sub_101A8
    
    mov esi, 0xA00BE
    call sub_101A8
    
    mov esi, 0xA0000
    call sub_101A8

    xor bx, bx
    mov ax, 0x1012
    mov cl, 0xFF
    mov edx, 0xA0000
    int 0x31              /* TRDOS 386 - VIDEO Interrupt */      

loc_10133:
    mov cx, 0x140
    mov edi, offset _1BAh
    xor ah, ah
    mov bl, 0x64
    
loc_1013E:
    mov al, [edi+0x27F]
    mov dl, [edi+0x280]
    add ax, dx
    mov dl, [edi+0x281]
    add ax, dx
    mov dl, [edi+0x500]
    add ax, dx
    shr ax, 2
    jz loc_1015B
    dec al
    
loc_1015B:
    mov [edi], al
    mov dl, [edi+0x500]
    add ax, dx
    shr ax, 1
    mov [edi+0x140], al
    inc edi
    loop loc_10133_jmp_bridge
    
    mov cx, 0x140
    add edi, ecx
    dec bl
    jnz loc_1013E
    
    mov edi, 0xA0000
    mov esi, offset _1BAh
    mov cx, 0x3B60
    rep movsd
    
    mov edi, 0xF8C0 + offset _1BAh
    mov cx, 0x13C
    
loc_10185:
    mov bl, ah   
    mov ah, 0             /* in (byte) */
    mov dx, 0x40
    int 0x34              /* TRDOS 386 - IOCTL */
    mov ah, bl

    add ax, [word_101B8]
    add [word_101B8], ax
    mov ah, al
    mov [edi], ax
    mov [edi+2], ax
    add edi, 4
    dec cx
    jnz loc_10185
    
    mov ah, 1
    int 0x32              /* TRDOS 386 - KEYBOARD Interrupt */
    jz loc_10133
    
    mov ax, 3
    int 0x31              /* TRDOS 386 - VIDEO Interrupt */   
    
terminate:
    /* sys _exit (int 40h) */
    mov ebx, 0            /* Exit code 0 */
    mov eax, _exit
    int 0x40
    
here:
    jmp here

/* Mesafe Aşımı Koruması İçin Kısa Atlama Köprüsü */
loc_10133_jmp_bridge:
    jmp loc_1013E

/* Orijinal VGA Renk Hesaplama Alt Rutini */
sub_101A8:
    mov cl, 0x40
    xor al, al
loc_101AC:
    mov [esi], al
    add al, ah
    add esi, 3
    loop loc_101AC
    ret

.section .data
.align 4
/* İmza Blokları ve Sabit Veriler */
.byte 0
.ascii "TRDOS 386"
.byte 0
.ascii "FLAME.PRG"
.byte 0
.ascii "ERDOGAN TAN"
.byte 0
.ascii "11/08/2016"
.byte 0

.align 2
word_101B8: .word 0x008D

.section .bss
.align 4
/* Ateş efektinin renderlandığı 16 KB+ tampon bölge */
_1BAh: .skip 0x5000
