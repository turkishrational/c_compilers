REM compile by using tcc.exe
tcc tbc.c getopt.c